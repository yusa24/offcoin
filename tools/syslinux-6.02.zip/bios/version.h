#define VERSION 6.02
#define VERSION_STR "6.02"
#define VERSION_MAJOR 6
#define VERSION_MINOR 2
#define YEAR 2013
#define YEAR_STR "2013"
