syslinux.run_command("memdisk initrd=/dos/BIOS/FSC-P7935-108.img raw")
