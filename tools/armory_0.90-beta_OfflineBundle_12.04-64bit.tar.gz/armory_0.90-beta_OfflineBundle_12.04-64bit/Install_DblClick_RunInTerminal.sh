#! /bin/bash

sudo dpkg -i *.deb
